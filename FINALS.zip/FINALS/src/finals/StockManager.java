
package finals;

import java.util.ArrayList;


public class StockManager {
    private ArrayList<Product> products;

    public StockManager(ArrayList<Product> products) {
        this.products = products;
    }

    public void receiveStock(String productId, int amount) {
        Transaction t = new ReceiveStock(productId, amount);
        t.process(products);
    }

    public void issueStock(String productId, int amount) {
        Transaction t = new IssueStock(productId, amount);
        t.process(products);
    }

    public void viewStockLevels() {
        for (Product p : products) {
            System.out.println(p.getName() + ": " + p.getQuantity());
        }
    }
}

