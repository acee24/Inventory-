/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finals;

import java.util.Scanner;

/**
 *
 * @author ACE
 */
public class FINALS {

   
    public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
        InventoryManager inv = new InventoryManager();
        SupplierManager sup = new SupplierManager();
        StockManager stock = new StockManager(inv.getProducts());

        while (true) {
            System.out.println("==== Inventory System ====");
            System.out.println("1. Products 2. Suppliers 3. Stock 4. Reports 5. Exit");
            System.out.print("Choice: ");

            switch (sc.nextInt()) {
                case 1 -> productMenu(sc, inv);
                case 2 -> supplierMenu(sc, sup);
                case 3 -> stockMenu(sc, stock);
                case 4 -> inv.viewProducts();
                case 5 -> { System.out.println("Exiting..."); return; }
                default -> System.out.println("Invalid.");
            }
        }
    }

    public static void productMenu(Scanner sc, InventoryManager m) {
        while (true) {
            System.out.println("-- Product Menu --");
            System.out.println("1.Add 2.View 3.Search 4.Update 5.Delete 6.Back");
            System.out.print("Choice: ");

            switch (sc.nextInt()) {
                case 1 -> {
                    sc.nextLine();
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Name: "); String name = sc.nextLine();
                    System.out.print("Qty: "); int qty = sc.nextInt();
                    m.addProduct(new Product(id, name, qty));
                }
                case 2 -> m.viewProducts();
                case 3 -> {
                    sc.nextLine();
                    System.out.print("ID: ");
                    Product p = m.findById(sc.nextLine());
                    System.out.println(p != null ? p.getName() + ", Qty: " + p.getQuantity() : "Not found.");
                }
                case 4 -> {
                    sc.nextLine();
                    System.out.print("ID: ");
                    Product p = m.findById(sc.nextLine());
                    if (p != null) {
                        System.out.print("New Name: "); p.setName(sc.nextLine());
                        System.out.print("New Qty: "); p.setQuantity(sc.nextInt());
                    } else System.out.println("Not found.");
                }
                case 5 -> {
                    sc.nextLine();
                    System.out.print("ID: "); m.deleteProduct(sc.nextLine());
                }
                case 6 -> { return;}
            }
        }
    }

    public static void supplierMenu(Scanner sc, SupplierManager m) {
        sc.nextLine();
        System.out.print("ID: "); String id = sc.nextLine();
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Contact: "); String contact = sc.nextLine();
        m.addSupplier(new Supplier(id, name, contact));
        m.viewSuppliers();
    }

    public static void stockMenu(Scanner sc, StockManager m) {
        while (true) {
            System.out.println("-- Stock Menu --");
            System.out.println("1.Receive 2.Issue 3.View 4.Back");
            System.out.print("Choice: ");

            switch (sc.nextInt()) {
                case 1 -> {
                    sc.nextLine();
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Qty: "); int qty = sc.nextInt();
                    m.receiveStock(id, qty);
                }
                case 2 -> {
                    sc.nextLine();
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Qty: "); int qty = sc.nextInt();
                    m.issueStock(id, qty);
                }
                case 3 -> m.viewStockLevels();
                case 4 -> {return;}
            }
        }
    }
}