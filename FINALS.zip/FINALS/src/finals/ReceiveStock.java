
package finals;

import java.util.ArrayList;

public class ReceiveStock extends Transaction {
    public ReceiveStock(String productId, int amount) {
        super(productId, amount);
    }

    @Override
    public void process(ArrayList<Product> products) {
        for (Product p : products) {
            if (p.getId().equals(productId)) {
                p.setQuantity(p.getQuantity() + amount);
                System.out.println("Received " + amount + " of " + p.getName());
                return;
            }
        }
        System.out.println("Product not found.");
    }
}
